n = int(input())
nums = []
for i in range(n):
    nums.append(int(input()))
for i in nums:
    print(i)
print(' ')
for i in nums:
    print(i * 3)