n = int(input())
purchases = []
for i in range(n):
    purchases.append(input())
for j in purchases:
    print(j)
