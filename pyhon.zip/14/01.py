def greet():
    name = input('Введите ваше имя: ')
    second_name = input('Введите вашу фамилию: ')
    print(f"Здравствуйте, {name} {second_name}" )


greet()