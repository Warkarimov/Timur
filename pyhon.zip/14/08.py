def print_shrug_smile():
    print('¯\_(ツ)_/¯')


def print_ktulhu_smile():
    print('{:€')


def print_happy_smile():
    print('(͡° ͜ʖ ͡°)')


print_happy_smile()
print_shrug_smile()
print_ktulhu_smile()