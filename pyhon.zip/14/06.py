def print_average(arr):
    print(sum(arr) / len(arr))


arr = [int(input()) for i in range(int(input()))]
print_average(arr)