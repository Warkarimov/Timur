for i in range(17):
    d = int(input())
    if i % d == 0:
        print('ДА')
    else:
        print('НЕТ')