days = 0
while True:
    temp = float(input())
    days += 1
    if temp == 22:
        print(int(days / 7))
        break