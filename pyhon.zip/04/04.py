num = 1
n = int(input())
for i in range(1, n):
    num = num * (i + 1)
print(num)