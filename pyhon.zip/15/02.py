def num_digits(number):
    return len(str(number))


print(num_digits(int(input())))