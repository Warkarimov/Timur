word1 = input()
word2 = input()
word3 = input()
if 'раз'  in word1 and 'два' in word2 and 'три' in word3:
    print('Гори')
elif '1' in word1 and '2' in word2 and '3' in word3:
    print('Гори')
else:
    print('Не гори')