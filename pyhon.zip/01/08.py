text = input()
if 'кот' in text:
    print('МЯУ')
else:
    print('ГАВ')