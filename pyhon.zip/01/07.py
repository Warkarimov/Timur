word = input()
print(4*word)