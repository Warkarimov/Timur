word = input()
if 'Python' in word:
    print('Да')
else:
    print('Нет')