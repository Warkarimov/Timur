word = input()
for i in range(len(word)):
    print(ord(word[i]), end=',')