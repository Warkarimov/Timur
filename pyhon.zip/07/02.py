word = input()
if word[0] == 'а':
    print('да')
else:
    print('нет')