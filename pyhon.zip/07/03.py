word = input()
print(word[-1])