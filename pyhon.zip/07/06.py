word = input()
for i in word:
    print(i)