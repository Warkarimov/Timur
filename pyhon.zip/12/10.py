s = input().split()
print(len(''.join(s)))