text = input().split()
print('["' + '","'.join(text) + '"]')