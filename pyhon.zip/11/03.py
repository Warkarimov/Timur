nums = ([i ** 2 for i in range(int(input()))])
for i in nums:
    print(i)
