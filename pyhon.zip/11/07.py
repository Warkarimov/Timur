text = input().split()
print('\n'.join(text))
