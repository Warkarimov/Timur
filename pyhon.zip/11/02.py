nums = [print(int(i) * '*') for i in input().split()]
