print(', '.join([ i for i in [(input()) for i in range(int(input()))] if 'лук' not in i]))
