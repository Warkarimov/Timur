city1 = input()
city2 = input()
if city1 == city2:
    print('НЕТ')
else:
    print('ДА')

