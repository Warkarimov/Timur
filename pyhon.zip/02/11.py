a = float(input())

if a > 0:
    print('+')
elif a < 0:
    print('-')
else:
    print(0)