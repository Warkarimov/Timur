days_per_year = 365
hours_per_day = 24
minutes_per_hour = 60
minutes_per_year = days_per_year * hours_per_day * minutes_per_hour
print(minutes_per_year)
