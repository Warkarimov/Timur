num_1 = float(input())
num_2 = float(input())
print(num_1 + num_2)