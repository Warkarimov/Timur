num_1 = int(input())
num_2 = int(input())
print(num_1 + num_2)