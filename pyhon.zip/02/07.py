n = float(input())
if abs(n) <= 1 / 1000000:
    print(1000000)
else:
    print(1 / n)
