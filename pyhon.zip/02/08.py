word = input()
print('Слово ' + str(word) + ' имеет длину ' + str(len(word)))