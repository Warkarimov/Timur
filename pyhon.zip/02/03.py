days = 2
lenght = 1843
work = 4
people = (lenght / (days * work))
if int(people) < people:
    print(int(people + 1))
else:
    print(int(people))