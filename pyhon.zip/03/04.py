while True:
    text = input()
    if text != '':
        print(text)
    else:
        while True:
            text = input()