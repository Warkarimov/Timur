temp  = float(input())
if temp < 15.5:
    print('Холодно')
elif temp > 28:
    print('Жарко')
else:
    print('Нормально')