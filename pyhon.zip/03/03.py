while True:
    num = int(input())
    if num != 0:
        print(num)
    else:
        while True:
            num = int(input())